<?php

namespace App\Models\Dashboard\Tublar\Tools;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ToolsExtensions extends Model
{
    use HasFactory;
   public $table='tools_extensions';
    public $guarded = [];
}
